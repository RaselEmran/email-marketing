<!DOCTYPE html>
<html>

@include('partials.htmlheader')

@yield('content')

</html>