<?php $__env->startSection('htmlheader_title'); ?>
    Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="row">
        <div class="col-md-1">

        </div>
        <div class="col-md-11">
            <section class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e($pageName); ?></h3>
                </div>
                <div class="box-body">

                    <?php echo Form::open(['url' => "/translation",'id'=>'project','class'=>'form-inline pull-right', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'Yes']); ?>


                    <div class="form-group required <?php echo e($errors->has('locale') ? ' has-error' : ''); ?>">
                        <?php echo Form::select('locale', $locals, null, ['id' => 'locale', 'class' =>'form-control select_box']); ?>

                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo e(trans('common.add') .' '.  trans('common.translation')); ?></button>

                    <?php echo Form::close(); ?>


                    <table class="table">
                        <thead>
                        <tr>
                            <td><?php echo trans('common.icon'); ?></td>
                            <td><?php echo trans('common.language'); ?></td>
                            <td><?php echo trans('common.progress'); ?></td>
                            <td><?php echo trans('common.done'); ?></td>
                            <td><?php echo trans('common.total'); ?></td>
                            <td><?php echo trans('common.action'); ?></td>
                        </tr>
                        </thead>

                        <tbody>
                        <?php foreach($languages as $language): ?>
                            <tr>
                                <td class="col-sm-1"><img src="<?php echo e(url('img/flags/'. strtolower(explode('_', \App\Models\Translation\Language::langDetail($language->locale)->locale)[1] . '.svg'))); ?>" style="width: 11px;height: 16px"></td>
                                <td><?php echo \App\Models\Translation\Language::langDetail($language->locale)->name; ?></td>

                                <td >
                                    <div class="progress">
                                        <?php
                                        $view_status = (int) (\App\Http\Controllers\Translation\TranslationController::getLangDirNumber($language->locale) / $totalTrans * 100);
                                        $status = 'danger';
                                        if ($view_status > 20) {
                                            $status = 'warning';
                                        } if ($view_status > 50) {
                                            $status = 'primary';
                                        } if ($view_status > 80) {
                                            $status = 'success';
                                        }
                                        ?>
                                        <div class="progress-bar progress-bar-<?php echo $status; ?>" role="progressbar" aria-valuenow="<?php echo $view_status; ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $view_status; ?>%;">
                                            <?php echo $view_status; ?>%
                                        </div>
                                    </div>

                                    </td>
                                <td class="col-sm-1"><?php echo \App\Http\Controllers\Translation\TranslationController::getLangDirNumber($language->locale); ?></td>
                                <td class="col-sm-1"><?php echo isset($totalTrans) ? $totalTrans : ''; ?></td>

                                <td class="col-sm-2">

                                    <a href="<?php echo e(url('/updateLanguage/'. $language->id )); ?>"><button class="btn <?php echo e($language->status == 1 ? 'btn-success' :'btn-danger'); ?> btn-xs" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('common.change')); ?>"><i class="fa fa-check"></i></button></a>
                                    <a href="<?php echo e(url('/translation?locale=' . $language->locale)); ?>"><button class="btn btn-primary btn-xs" data-toggle="tooltip" data-placement="top" title="<?php echo e(trans('common.edit')); ?>"><i class="fa fa-edit"></i></button></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>

                </div>
            </section>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>