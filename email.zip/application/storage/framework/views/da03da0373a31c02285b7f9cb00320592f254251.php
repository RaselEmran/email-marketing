<?php $__env->startSection('htmlheader_title'); ?>
    Register
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <body class="register-page">
    <div class="register-logo" style="margin-top: 60px">
        <a href="<?php echo e(url('/home')); ?>"><?php echo configValue('site_name'); ?></a>
    </div>
    <div class="register-box">


        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> <?php echo trans('auth.input_error'); ?> <br><br>
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php elseif(Session::has('login_error_msg')): ?>
            <div class="alert alert-danger">
                <ul>
                    <li><?php echo e(Session::get('login_error_msg')); ?></li>
                </ul>
            </div>
        <?php endif; ?>

        <div class="register-box-body">
            <div class="text-center">
                <div class="icon-object border-success text-success" style="padding: 17px 21px;margin: 0px"><i class="fa fa-plus" style="font-size: 22px"></i></div>
                <h4 style="letter-spacing: -.015em;font-size: 15px" class="content-group"><?php echo trans('auth.Create account'); ?> <small class="display-block"><?php echo trans('auth.required_field'); ?></small></h4>
            </div>


            <form action="<?php echo e(url('/register')); ?>" method="post">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                <div class="form-group has-feedback">
                    <input type="text" class="form-control" placeholder="<?php echo trans('auth.fullname'); ?>" name="name"
                           value="<?php echo e(old('name')); ?>"/>
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="email" class="form-control" placeholder="<?php echo trans('common.email'); ?>" name="email"
                           value="<?php echo e(old('email')); ?>"/>
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" placeholder="<?php echo trans('common.password'); ?>" name="password"/>
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" placeholder=" <?php echo trans('common.Retype').' '.trans('common.password'); ?>"
                           name="password_confirmation"/>
                    <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
                </div>

                <div class="checkbox icheck " style="margin-top: 20px;margin-bottom: 20px">
                    <label>
                        <input type="checkbox"> <?php echo trans('auth.agrre_the'); ?> <a target="_blank" href="<?php echo e(url('termsCondition')); ?>"><?php echo trans('auth.terms'); ?></a> <?php echo trans('common.and'); ?> <a target="_blank" href="<?php echo e(url('privacyPolicy')); ?>"><?php echo trans('common.privacy_policy'); ?></a>
                    </label>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-login btn-block"><?php echo trans('auth.Register'); ?> <i class="fa fa-arrow-right"></i>
                    </button>
                </div>
            </form>

            <div class="social-auth-links text-center">
                <p class="text-muted"> <?php echo trans('auth.or sign in with'); ?>  </p>
                <ul class="list-inline social-btn text-center">
                    <li><a href="<?php echo e(url('facebook')); ?>" class="btn btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="<?php echo e(url('google')); ?>" class="btn btn-social-icon btn-google"><i class="fa fa-google-plus"></i></a></li>
                    <li><a href="<?php echo e(url('twitter')); ?>" class="btn btn-social-icon btn-twitter"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="<?php echo e(url('linkedin')); ?>" class="btn btn-social-icon btn-linkedin"><i class="fa fa-linkedin"></i></a></li>
                    <li><a href="<?php echo e(url('github')); ?>" class="btn btn-social-icon btn-github"><i class="fa fa-github"></i></a></li>
                </ul>
            </div>
            <!-- /.social-auth-links -->
            <div class="content-divider text-muted form-group "><span><?php echo trans('auth.already_member'); ?></span></div>
            <a href="<?php echo e(url('/login')); ?>" style="padding: 6px" class="btn btn-default btn-block content-group"><?php echo trans('auth.log_in'); ?></a>
        </div>
        <!-- /.form-box -->
    </div>
    <!-- /.register-box -->

    <?php echo $__env->make('auth.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script>
        $(function () {
            $('input').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                radioClass: 'iradio_square-blue',
                increaseArea: '20%' // optional
            });
        });
    </script>
    </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>