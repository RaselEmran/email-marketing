<div class="form-group required">
    <?php echo Form::label('name',trans('auth.fullname'),['class'=>' col-lg-3 control-label company-label']); ?>

    <div class="col-lg-5">
        <?php echo Form::text('name',null, ['id' => 'name', 'class' =>'form-control ', 'required' => 'true']); ?>

        <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
    </div>
</div>
<div class="form-group required">
    <?php echo Form::label('email',trans('common.email'),['class'=>' col-lg-3 control-label company-label']); ?>

    <div class="col-lg-5">
        <?php echo Form::text('email',null, ['id' => 'email', 'class' =>'form-control ', 'required' => 'true']); ?>

        <p class="text-danger"><?php echo e($errors->first('email')); ?></p>
    </div>
</div>
<?php if(!isset($userInfo)): ?>
<div class="form-group required">
    <?php echo Form::label('password',trans('common.password'),['class'=>' col-lg-3 control-label company-label']); ?>

    <div class="col-lg-5">
        <?php echo Form::password('password', ['id' => 'password', 'class' =>'form-control ', 'maxlength' => '50', 'required' => 'true']); ?>

        <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
    </div>
</div>
<?php endif; ?>
<div class="form-group">
    <div class="col-lg-5 col-lg-offset-3">
        <?php echo Form::submit($submit_button,['class' => 'btn btn-sm btn-primary pull-right']); ?>

    </div>
</div>
