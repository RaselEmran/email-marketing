<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<div class="row">
<div class="col-md-1">

</div>
		<div class="col-md-9">
			<section class="box box-default">
				<div class="box-header with-border">
					<h3 class="box-title"><?php echo e($pageName); ?></h3>
				</div>
				<div class="box-body">

					<?php echo Form::open(['url' => "theme",'id'=>'foo','class'=>'form-horizontal', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'No']); ?>


					<?php echo $__env->make('Theme._form',['submit_button' => 'Submit'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

					<?php echo Form::close(); ?>


				</div>
			</section>
		</div>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>