<?php $__env->startSection('main-content'); ?>
    <div class="nav-tabs-custom">
        <!-- Tabs within a box -->
        <ul class="nav nav-tabs">
            <li <?php if($errors->has() || isset($userInfo)): ?> class="" <?php else: ?> class="active" <?php endif; ?> ><a href="#all_users"
                                                                                                  data-toggle="tab">All
                    Users</a></li>
            <?php if(Auth::user()->role == 'admin' || (isset($userInfo) && ($userInfo->id == Auth::id()))): ?>
                <li <?php if($errors->has() || isset($userInfo)): ?> class="active" <?php else: ?> class="" <?php endif; ?> ><a href="#manage_users"
                                                                                                  data-toggle="tab"><?php echo e($title); ?></a>
                </li>
            <?php endif; ?>
        </ul>
        <div class="tab-content no-padding">
            <!-- ************** general *************-->
            <div <?php if($errors->has() || isset($userInfo)): ?> class="tab-pane" <?php else: ?> class="tab-pane active"
                 <?php endif; ?> id="all_users">

                <table class="table table-hover" id="dataTables">
                    <thead>
                    <tr class="active">
                        <th class="col-sm-1">#</th>
                        <th><?php echo trans('common.name'); ?></th>
                        <th><?php echo trans('common.email'); ?></th>
                        <th><?php echo trans('common.role'); ?></th>
                        <th><?php echo trans('common.status'); ?></th>
                        <th><?php echo trans('common.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($allUsers) > 0): ?>
                        <?php foreach($allUsers as $key =>$user): ?>
                            <tr>
                                <td><a href="<?php echo e(url('profile/'.$user->id)); ?>"><?php echo $key+1; ?></a></td>
                                <td><i class="fa fa-<?php echo e($user->platform); ?>"></i> <a href="<?php echo e(url('profile/'.$user->id)); ?>"><?php echo $user->name; ?></a></td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php if($user->role == 'admin'): ?>
                                        <span class="label label-warning">Admin</span>
                                    <?php else: ?>
                                        <span class="label label-info">User</span>
                                    <?php endif; ?>
                                </td>
                                <td><span <?php if($user->status == 'Active'): ?> class="label label-success"
                                          <?php elseif($user->status == 'Banned'): ?> class="label label-danger"
                                          <?php endif; ?>> <a style="color: white;" href="<?php echo e(url("users/change_status/$user->id")); ?>"><?php echo e($user->status); ?></a> </span>
                                </td>
                                <td>
                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id], 'class' => 'delete-form']); ?>

                                    <?php if($user->status == 'Active'): ?>
                                        <?php echo btn_banned(url("users/change_status/$user->id")); ?>

                                    <?php elseif($user->status == 'Banned'): ?>
                                        <?php echo btn_active(url("users/change_status/$user->id")); ?>

                                    <?php endif; ?>
                                        <?php echo btn_edit("users/$user->id/edit"); ?>

                                        <?php if($user->role != 'admin'): ?>
                                        <?php echo btn_delete_submit(); ?>

                                        <?php endif; ?>
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div <?php if($errors->has() || isset($userInfo)): ?> class="tab-pane active" <?php else: ?> class="tab-pane"
                 <?php endif; ?> id="manage_users">
                <?php if( !isset($userInfo) ): ?>
                    <?php if(Auth::user()->role == 'admin'): ?>
                        <?php echo Form::open(['url' => "users",'id'=>'client','class'=>'form-horizontal', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'No', 'files' => true]); ?>


                        <?php echo $__env->make('users._form',['submit_button' => 'Submit'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                <?php else: ?>
                    <?php echo Form::model($userInfo,['method' =>'PUT', 'url' => ["users",$userInfo->id],'id'=>'users','class'=>'form-horizontal', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'Yes', 'files' => true]); ?>


                    <?php echo $__env->make('users._form',['submit_button' => 'Update'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>