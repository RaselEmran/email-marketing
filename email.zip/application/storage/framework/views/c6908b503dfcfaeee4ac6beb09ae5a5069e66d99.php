<html>
<head>
    <meta charset="UTF-8">
    <title> Email Marketing | Installation </title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <!-- Bootstrap 3.3.4 -->
    <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
    <script src="<?php echo e(asset('/plugins/jQuery/jQuery-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
</head>
<style>
    body {
        background-color: #F2F2F2;

    }

    .room {
        background-color: #fff;
        margin-bottom: 20px;
        box-shadow: 0 -1px 0 #e5e5e5, 0 0 2px rgba(0, 0, 0, .12), 0 2px 4px rgba(0, 0, 0, .24);

    }

    table {
        font-size: 14px
    }

    tbody > tr > td .label {
        line-height: 1.5384616;
    }

    table a {
        color: #333;
    }
</style>

<body>
<div class="container" style="margin-top:50px ">
    <div class="row">
        <div class="col-md-6 col-md-offset-3 " style=" padding-top: 10px;">
            <div class="panel panel-primary room">
                <div class="panel-heading">
                    <strong>
                         Email Marketing | Installation
                    </strong>
                </div>
                <?php /*<-- system requirements Start-->*/ ?>
                <div class="panel-body" id="extensions">
                    <h4 class="text-center">System Requirements</h4>
                    <hr style="margin: 0px"/>
                    <?php if(Session::has('extensions_error')): ?>
                        <div style="padding-top: 10px; padding-bottom: 10px;">
                            <p class="text-danger text-center"><?php echo e(Session::get('extensions_error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <td>Extensions</td>
                            <td>Result</td>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td>PHP 5.5.9 +</td>
                            <?php if($php_version['actual']): ?>
                                <td><span class="label label-success">PHP <?php echo e($php_version['version']); ?></span></td>
                            <?php else: ?>
                                <td><span class="label label-danger">PHP <?php echo e($php_version['version']); ?></span></td>
                            <?php endif; ?>
                        </tr>
                        <?php foreach($extensions as $ext): ?>
                            <tr>
                                <td><a target="_blank" href="<?php echo e($ext['link']); ?>"> <?php echo e($ext['name']); ?></a></td>
                                <?php if($ext['expected'] === $ext['actual']): ?>
                                    <td>
                                        <span class="label label-success"><?php echo e(($ext['actual'] === true)? 'Enable' : 'Disable'); ?></span>
                                    </td>
                                <?php else: ?>
                                    <td>
                                        <span class="label label-danger"><?php echo e(($ext['actual'] === true)? 'Enable' : 'Disable'); ?></span>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                    <div class="form-group last" style="display: <?php if($extensions_problem): ?> none; <?php endif; ?> ">
                        <div class="pull-right ">
                            <button type="submit" class="btn btn-primary btn-sm"
                                    onclick="next('extensions', '<?php echo e($extensions_problem); ?>')" id="submit">Next <i
                                        class="glyphicon glyphicon-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
                <?php /*<-- system requirements End-->*/ ?>
                <?php /*=== **************** ======*/ ?>

                <?php /*<-- system requirements Start-->*/ ?>
                <div class="panel-body" id="folders">
                    <h4 class="text-center">Permissions</h4>
                    <hr style="margin: 0px"/>
                    <?php if(Session::has('folders_error')): ?>
                        <div style="padding-top: 10px; padding-bottom: 10px;">
                            <p class="text-danger text-center"><?php echo e(Session::get('folders_error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                        <tr>
                            <td>Directory</td>
                            <td>Result</td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach($folderWritable as $folderWri): ?>
                            <tr>
                                <td><?php echo e($folderWri['path']); ?></td>
                                <?php if($folderWri['writable']): ?>
                                    <td><span class="label label-success">Writable</span></td>
                                <?php else: ?>
                                    <td><span class="label label-danger">not writable</span></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>

                        </tbody>
                    </table>
                    <div class="form-group last" style="display: <?php if($folders_problem): ?> none <?php endif; ?>">
                        <div class="pull-right ">
                            <button type="submit" class="btn btn-primary btn-sm"
                                    onclick="next('folders', '<?php echo e($folders_problem); ?>')" id="submit">Next <i
                                        class="glyphicon glyphicon-arrow-right"></i></button>
                        </div>
                    </div>
                </div>
                <?php /*<-- system requirements End-->*/ ?>
                <?php /*=== **************** ======*/ ?>

                <?php /*<-- Database Configuration Start-->*/ ?>
                <div class="panel-body" id="database">

                    <h4 class="text-center">Database Configuration</h4>
                    <hr style="margin: 0px"/>
                    <?php if(Session::has('connection_error')): ?>
                        <div style="padding-top: 10px;">
                            <p class="text-danger text-center"><?php echo e(Session::get('connection_error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(url('install/store')); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                        <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label text-right">Hostname</label>

                            <div class="col-md-9">
                                <input type="text" class="form-control" name="host" id="host"
                                       value="<?php echo e((old('host'))? old('host') :'localhost'); ?>" placeholder="">

                                <p class="text-danger"><?php echo e($errors->first('host')); ?></p>
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="database_name" class="col-md-3 control-label text-right">Database Name</label>

                            <div class="col-md-9">
                                <input type="text" class="form-control" name="database_name" id="database_name"
                                       value="<?php echo e(old('database_name')); ?>" placeholder="">

                                <p class="text-danger"><?php echo e($errors->first('database_name')); ?></p>
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="username" class="col-md-3 control-label text-right">Username</label>

                            <div class="col-md-9">
                                <input type="text" name="username" class="form-control" id="username"
                                       value="<?php echo e(old('username')); ?>" placeholder="">

                                <p class="text-danger"><?php echo e($errors->first('username')); ?></p>
                            </div>
                        </div>
                        <div class="form-group ">
                            <label for="password" class="col-md-3 control-label text-right">Password</label>

                            <div class="col-md-9">
                                <input type="password" name="password" class="form-control" id="password"
                                       placeholder="">

                                <p class="text-danger"><?php echo e($errors->first('password')); ?></p>
                            </div>
                        </div>
                        <div class="form-group last">
                            <div class="col-sm-offset-3 col-sm-8">
                                <button type="submit" class="btn btn-success btn-sm" id="submit">Install</button>
                                <button type="reset" class="btn btn-default btn-sm">Reset</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel-footer"><a target="_blank" href="http://www.xcoder.io" style="color: #333"> ©
                        xcoder.io</a>
                </div>
            </div>

        </div>
    </div>
</div>
<script>
    $(function () {
        <?php if(Session::has('extensions_error')): ?>
            $('#folders').addClass('hidden');
        $('#database').addClass('hidden');
        <?php elseif(Session::has('folders_error')): ?>
            $('#extensions').addClass('hidden');
        $('#database').addClass('hidden');
        <?php elseif(Session::has('connection_error')): ?>
            $('#extensions').addClass('hidden');
        $('#folders').addClass('hidden');
        <?php else: ?>
            $('#folders').addClass('hidden');
        $('#database').addClass('hidden');
        <?php endif; ?>

    });

    function next(check_type, problem) {
        if ((check_type == 'extensions') && (!problem)) {
            $('#extensions').addClass('hidden');
            $('#folders').removeClass('hidden');
            if (!$('#database').hasClass('hidden')) {
                $('#database').addClass('hidden');
            }
        } else if ((check_type == 'folders') && (!problem)) {
            if (!$('#extensions').hasClass('hidden')) {
                $('#extensions').addClass('hidden');
            }
            $('#folders').addClass('hidden');
            $('#database').removeClass('hidden');
        }
    }
</script>

</body>
</html>


