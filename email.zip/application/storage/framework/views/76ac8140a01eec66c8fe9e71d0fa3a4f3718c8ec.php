<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        <div class="user-panel">
            <div class="pull-left image">
                <?php if(Auth::check() && (isset(Auth::user()->photo)) && (Auth::user()->photo != '')): ?>
                    <?php if(strpos(Auth::user()->photo, 'http') !== false): ?>
                        <img src="<?php echo e(Auth::user()->photo); ?>" style="height: 45px; width: 45px;" class="img-circle" alt="User Image" />
                    <?php else: ?>
                        <img src="<?php echo e(url('upload/'.Auth::user()->photo)); ?>" style="height: 45px; width: 45px;" class="img-circle" alt="User Image" />
                    <?php endif; ?>
                <?php else: ?>
                    <img src=<?php echo e(url('img/user2-160x160.jpg')); ?> class="img-circle" alt="User Image" />
                <?php endif; ?>
            </div>
            <div class="pull-left info">
                <?php if(Auth::check()): ?>
                <p><?php echo e(Auth::user()->name); ?></p>
                <?php else: ?>
                <p>John Doe</p>
                <?php endif; ?>
                    <!-- Status -->
                <?php if(Auth::check()): ?>
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo trans('common.online'); ?></a>
                <?php endif; ?>
            </div>
        </div>
    <?php $url = Request::segment(1); ?>
        <!-- Sidebar Menu -->
        <ul class="sidebar-menu">
            <li class="<?php echo e(($url == 'home' || $url == '')? "active" : ''); ?>"><a href="<?php echo e(url('home')); ?>"><i class='fa fa-dashboard'></i> <span><?php echo trans('common.Dashboard'); ?></span></a></li>
            <li class="<?php echo e(($url == 'users')? "active" : ''); ?>"><a href="<?php echo e(url('users')); ?>"><i class='fa fa-users'></i> <span><?php echo trans('common.users'); ?></span></a></li>
            <li class="<?php echo e(($url == 'email-list')? "active" : ''); ?>"><a href="<?php echo e(url('email-list')); ?>"><i class='fa fa-list'></i> <span><?php echo trans('common.email-list'); ?></span></a></li>
            <li class="<?php echo e(($url == 'template')? "active" : ''); ?>"><a href="<?php echo e(url('template')); ?>"><i class='fa fa-newspaper-o'></i> <span><?php echo trans('common.template'); ?></span></a></li>
            <li class="<?php echo e(($url == 'media')? "active" : ''); ?>"><a href="<?php echo e(url('media')); ?>"><i class='fa fa-picture-o'></i> <span><?php echo trans('common.media'); ?></span></a></li>
            <li class="<?php echo e(($url == 'send-mail')? "active" : ''); ?>"><a href="<?php echo e(url('send-mail')); ?>"><i class='fa fa-envelope'></i> <span><?php echo trans('common.send-mail'); ?></span></a></li>
            <li class="<?php echo e(($url == 'history')? "active" : ''); ?>"><a href="<?php echo e(url('history')); ?>"><i class='fa fa-list-alt'></i> <span><?php echo trans('common.history'); ?></span></a></li>
            <li class="<?php echo e(($url == 'activities')? "active" : ''); ?>"><a href="<?php echo e(url('activities')); ?>"><i class='fa fa-list-alt'></i> <span><?php echo trans('common.Activities'); ?></span></a></li>
            <?php if(Auth::check() &&  Auth::user()->role == 'admin'): ?>
            <li class="treeview <?php echo e((($url == 'oauth') || ($url == 'email') || ($url == 'theme')|| ($url == 'translation') || ($url == 'privacy')) ? "active" : ''); ?>">
                <a href="#"><i class='fa fa-cogs'></i> <span><?php echo trans('common.Settings'); ?></span> <i class="fa fa-angle-right pull-right"></i></a>
                <ul class="treeview-menu">
                    <li class="<?php echo e(($url == 'email')? "active" : ''); ?>"><a href="<?php echo e(url('email')); ?>"><i class='fa fa-envelope-o'></i> <span><?php echo trans('common.email').' '.trans('common.Settings'); ?></span></a></li>
                    <!-- <li class="<?php echo e(($url == 'api')? "active" : ''); ?>"><a href="<?php echo e(url('api')); ?>"><i class='fa fa-envelope-o'></i> <span><?php echo trans('common.api'); ?></span></a></li> -->
                    <li class="<?php echo e(($url == 'oauth')? "active" : ''); ?>"><a href="<?php echo e(url('oauth')); ?>"><i class='fa fa-facebook'></i> <span><?php echo trans('common.oauth').' '.trans('common.Settings'); ?></span></a></li>
                    <li class="<?php echo e(($url == 'theme')? "active" : ''); ?>"><a href="<?php echo e(url('theme')); ?>"><i class='fa fa-codepen'></i> <span><?php echo trans('common.Theme').' '.trans('common.Settings'); ?></span></a></li>
                    <li class="<?php echo e(($url == 'translation')? "active" : ''); ?>"><a href="<?php echo e(url('translation')); ?>"><i class='fa fa-language'></i> <span><?php echo trans('common.Translation'); ?></span></a></li>
                    <li class="<?php echo e(($url == 'privacy')? "active" : ''); ?>"><a href="<?php echo e(url('privacy')); ?>"><i class='fa fa-archive'></i> <span><?php echo trans('common.privacy'); ?></span></a></li>
                </ul>
            </li>
            <?php endif; ?>
            <li class="<?php echo e(($url == 'backupDownload')? "active" : ''); ?>"><a href="<?php echo e(url('backupDownload')); ?>"><i class='fa fa-database'></i> <span><?php echo trans('common.backup'); ?></span></a></li>
        </ul><!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
</aside>
