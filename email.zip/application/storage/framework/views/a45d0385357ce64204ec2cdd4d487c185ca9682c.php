<?php $__env->startSection('htmlheader_title'); ?>
    Home
    <?php $__env->stopSection(); ?>
            <!-- CK Editor -->
    <script src="https://cdn.ckeditor.com/4.4.3/standard/ckeditor.js"></script>

<?php $__env->startSection('main-content'); ?>
    <div class="box box-default">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo trans('common.only_privacy'); ?></h3>
        </div>
        <div class="box-body">
            <?php echo Form::open(['url' => "/privacy",'id'=>'oauth','class'=>'', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'Yes']); ?>

            <?php echo Form::textarea('privacy',configValue('privacy')?configValue('privacy'):null, ['id' => 'editor1', 'class' =>'form-control']); ?>

            <br/>
            <?php echo Form::submit('update',['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
    <div class="box box-default">
        <div class="box-header with-border">
            <h3 class="box-title"><?php echo trans('common.term&condition'); ?></h3>
        </div>
        <div class="box-body">
            <?php echo Form::open(['url' => "/storeTerms",'id'=>'oauth','class'=>'', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'Yes']); ?>

            <?php echo Form::textarea('termCondition',configValue('termCondition')?configValue('termCondition'):null, ['id' => 'editor2', 'class' =>'form-control']); ?>

            <br/>
            <?php echo Form::submit('update',['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
    <script>
        $(function () {
            // Replace the <textarea id="editor1"> with a CKEditor
            // instance, using default configuration.
            CKEDITOR.replace('editor1');
            CKEDITOR.replace('editor2');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>