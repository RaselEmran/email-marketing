<!-- Content Header (Page header) -->
<section class="content-header">
    <h1>
        <?php /*<?php echo $__env->yieldContent('contentheader_title', 'Page Header here'); ?>*/ ?>
        <small><?php echo $__env->yieldContent('contentheader_description'); ?></small>
    </h1>

    <?php echo $__env->make('partials.breadcrumb', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


</section>