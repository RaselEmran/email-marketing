<?php $__env->startSection('htmlheader_title'); ?>
    Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
    <style type="text/css">
        .form-control-static {
            padding-top: 3px;
        }

        .control-label {
            font-weight: bold;

        }
    </style>
    <div class="row">
        <div class="col-md-1">

        </div>
        <div class="col-md-10">
            <section class="box box-default">
                <div class="box-header with-border">
                    <h3 class="box-title"><?php echo e($pageName); ?></h3>
                </div>
                <div class="box-body form-horizontal">

                    <div class="row">
                        <label for="inputEmail3" class="col-sm-2 control-label text-left"><?php echo trans('common.name'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <?php echo e($user->name); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label for="inputEmail3" class="col-sm-2 control-label text-left"><?php echo trans('common.email'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <?php echo e($user->email); ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label for="inputEmail3" class="col-sm-2 control-label text-left"><?php echo trans('common.role'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <?php if($user->role == 'admin'): ?>
                                    <span class="label label-warning"><?php echo e(trans('common.admin')); ?></span>
                                <?php else: ?>
                                    <span class="label label-info"><?php echo e(trans('common.user')); ?></span>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label for="inputEmail3" class="col-sm-2 control-label text-left"><?php echo trans('common.status'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <?php if($user->status == 'Active'): ?>
                                    <span class="label label-success"><?php echo e($user->status); ?></span>
                                <?php else: ?>
                                    <span class="label label-danger"><?php echo e($user->status); ?></span>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label for="inputEmail3"
                               class="col-sm-2 control-label text-left"><?php echo trans('common.create_at'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <span class="label label-danger"><?php echo e($user->created_at); ?></span>

                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <label for="inputEmail3" class="col-sm-2 control-label text-left"><?php echo trans('common.photo'); ?>

                            :</label>

                        <div class="col-sm-10">
                            <div class="form-control-static">
                                <?php if(Request::segment(2) && (Request::segment(2) != Auth::id()) && (Auth::user()->role != 'admin')): ?>)
                                    <div class="fileinput-new thumbnail" style="width: 210px;">
                                        <?php if(isset($user->photo) && ($user->photo != '')): ?>
                                            <?php if(strpos($user->photo, 'http') === false): ?>
                                                <?php echo Html::image('upload/'.$user->photo); ?>

                                            <?php else: ?>
                                                <img src="<?php echo e($user->photo); ?>" alt="User Image"/>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <img src="<?php echo e(url('img/default.png')); ?>"
                                                 alt="No Photo">
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <?php echo Form::open(['url' => "profile",'id'=>'profile','class'=>'form-horizontal', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'No','files' => true]); ?>

                                    <div class="form-group required">
                                        <div class="col-md-5">
                                            <div class="fileinput fileinput-new" data-provides="fileinput">
                                                <div class="fileinput-new thumbnail" style="width: 210px;">
                                                    <?php if(isset($user->photo) && ($user->photo != '')): ?>
                                                        <?php if(strpos($user->photo, 'http') === false): ?>
                                                            <?php echo Html::image('upload/'.$user->photo); ?>

                                                        <?php else: ?>
                                                            <img src="<?php echo e($user->photo); ?>" alt="User Image"/>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <img src="<?php echo e(url('img/default.png')); ?>"
                                                             alt="No Photo">
                                                    <?php endif; ?>
                                                </div>
                                                <div class="fileinput-preview fileinput-exists thumbnail"
                                                     style="width: 210px;"></div>
                                                <div>
                                                <span class="btn btn-default btn-file">
                                                    <span class="fileinput-new">
                                                        <input type="file" name="photo" value="upload"
                                                               data-buttonText="<?= trans('choose_file') ?>"
                                                               id="myImg"/>
                                                        <span class="fileinput-exists"><?php echo trans('common.Change'); ?></span>
                                                    </span>
                                                    <a href="#" class="btn btn-default fileinput-exists"
                                                       data-dismiss="fileinput"><?php echo trans('common.remove'); ?></a>
                                                </span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="user" value="<?php echo e($user->id); ?>">

                                    <button type="submit" class="btn btn-primary"><?php echo trans('common.upload'); ?></button>
                                    <?php echo Form::close(); ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>