<div class="form-group required">
    <?php echo Form::label('title',trans('common.title')); ?>

    <?php echo Form::text('title',null, ['id' => 'title', 'class' =>'form-control', 'required' => 'true']); ?>

    <p class="text-danger"><?php echo e($errors->first('title')); ?></p>
</div>

<div class="form-group required">
    <?php echo Form::label('media',trans('common.media')); ?>

    <?php echo Form::file('media',null, ['id' => 'media', 'class' =>'form-control', 'required' => 'true']); ?>

    <p class="text-danger"><?php echo e($errors->first('caption')); ?></p>
</div>

<div class="form-group">
    <?php echo Form::submit($submit_button,['class' => 'btn btn-sm btn-primary']); ?>

</div>