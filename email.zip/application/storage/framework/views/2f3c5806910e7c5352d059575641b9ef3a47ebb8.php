<!-- Main Header -->
<header class="main-header">

    <!-- Logo -->
    <a href="<?php echo e(url('/home')); ?>" class="logo">
        <!-- mini logo for sidebar mini 50x50 pixels -->
        <span class="logo-mini"><b>A</b>LT</span>
        <!-- logo for regular state and mobile devices -->
        <span class="logo-lg"><?php echo configValue('site_name'); ?></span>
    </a>

    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
        </a>
        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                         <?php echo getLang(env('locale', trans('common.Languages'))); ?>

                    </a>
                    <ul class="dropdown-menu">
                        <?php foreach(\App\Models\Translation\Language::where('status',1)->get() as $lang): ?>
                            <li>
                                <a href="<?php echo url('lang/'.$lang->locale); ?>"
                                   title="<?php echo \App\Models\Translation\Language::langDetail($lang->locale)->name; ?>">
                                    <img style="width: 15px;height: 16px"
                                         src="<?php echo e(url('img/flags/'.strtolower(explode('_',$lang->locale)[1]).'.svg')); ?>"
                                         alt="<?php echo $lang->locale; ?>"> <?php echo \App\Models\Translation\Language::langDetail($lang->locale)->name; ?>

                                </a>
                            </li>
                        <?php endforeach; ?>
                        <li><a href="<?php echo url('translation'); ?>"><?php echo trans('common.add_new_languages'); ?></a></li>
                    </ul>
                </li>
                <!-- User Account Menu -->
                <li class="dropdown user user-menu">
                    <!-- Menu Toggle Button -->
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <!-- The user image in the navbar-->
                        <?php if(Auth::check() && isset(Auth::user()->photo) && (Auth::user()->photo != '')): ?>
                            <?php if(strpos(Auth::user()->photo, 'http') !== false): ?>
                                <img src="<?php echo e(Auth::user()->photo); ?>" class="user-image" alt="User Image"/>
                            <?php else: ?>
                                <img src="<?php echo e(url('upload/'.Auth::user()->photo)); ?>" class="user-image" alt="User Image"/>
                            <?php endif; ?>
                        <?php else: ?>
                            <img src="<?php echo e(url('img/user2-160x160.jpg')); ?>" class="user-image" alt="User Image"/>
                            <?php endif; ?>
                                    <!-- hidden-xs hides the username on small devices so only the image appears. -->
                            <?php if(Auth::check()): ?>
                                <span class="hidden-xs"><?php echo e(Auth::user()->name); ?></span>
                            <?php else: ?>
                                <span class="hidden-xs">John Doe</span>
                            <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu">
                        <!-- The user image in the menu -->
                        <li class="user-header">
                            <?php if(Auth::check() && isset(Auth::user()->photo) && (Auth::user()->photo != '')): ?>
                            <?php if(strpos(Auth::user()->photo, 'http') !== false): ?>
                                    <img src="<?php echo e(Auth::user()->photo); ?>" class="img-circle"
                                         alt="User Image"/>
                                <?php else: ?>
                                    <img src="<?php echo e(url('upload/'.Auth::user()->photo)); ?>" class="img-circle"
                                         alt="User Image"/>
                                <?php endif; ?>

                            <?php else: ?>
                                <img src="<?php echo e(url('img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image"/>
                            <?php endif; ?>
                            <?php if(Auth::check()): ?>
                                <p>
                                    <?php echo e(Auth::user()->name); ?>

                                    <small><?php echo trans('common.Member since'); ?> <?php echo e(date('M Y', strtotime(Auth::user()->created_at))); ?></small>
                                </p>
                            <?php endif; ?>
                        </li>
                        <!-- Menu Body -->
                        <?php if(Auth::check()): ?>
                            <li class="user-body">
                                <div class="col-xs-7 text-center pull-left">
                                    <a href="<?php echo e(url('users/update_password')); ?>"><?php echo e(trans('common.change'). ' ' . trans('common.password')); ?></a>
                                </div>
                                <div class="col-xs-4 text-center pull-right">
                                    <a href="<?php echo e(url('activities/'.Auth::id())); ?>"><?php echo trans('common.Activities'); ?></a>
                                </div>
                            </li>
                            <?php endif; ?>
                                    <!-- Menu Footer-->
                            <li class="user-footer">
                                <div class="pull-left">
                                    <a href="<?php echo e(url('profile')); ?>"
                                       class="btn btn-default btn-flat"><?php echo trans('common.Profile'); ?></a>
                                </div>
                                <div class="pull-right">
                                    <a href="<?php echo e(url('/logout')); ?>"
                                       class="btn btn-default btn-flat"><?php echo trans('common.Sign out'); ?></a>
                                </div>
                            </li>
                    </ul>
                </li>
                <!-- Control Sidebar Toggle Button -->
                <li>
                    <a style="visibility: hidden" href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
                </li>
            </ul>
        </div>
    </nav>
</header>