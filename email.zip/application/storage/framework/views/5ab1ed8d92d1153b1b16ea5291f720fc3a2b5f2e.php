<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>

<?php echo $__env->make('partials.htmlheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<body class="skin-<?php echo configValue('sidebar_theme') ? configValue('sidebar_theme'):'red-light'; ?> sidebar-mini">
<div class="wrapper">

    <?php echo $__env->make('partials.mainheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <?php echo $__env->make('partials.contentheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Main content -->
        <section class="content">

            <?php $alert_type = ''; $msg = ''; ?>
            <?php if(Session::has('success_msg')): ?>
            <?php $alert_type = 'success';
            $msg = Session::get('success_msg');
            Session::forget('success_msg');
            ?>
            <?php elseif(Session::has('error_msg')): ?>
            <?php $alert_type = 'error';
            $msg = Session::pull('error_msg');
            ?>
            <?php elseif(Session::has('info_msg')): ?>
            <?php $alert_type = 'info';
            $msg = Session::pull('info_msg');
            ?>
            <?php elseif(Session::has('warning_msg')): ?>
            <?php $alert_type = 'warning';
            $msg = Session::pull('warning_msg');
            ?>
            <?php else: ?>
            <?php $alert_type = '';
            $msg = '';
            ?>
            <?php endif; ?>
            <!-- Your Page Content Here -->
            <?php echo $__env->yieldContent('main-content'); ?>
        </section><!-- /.content -->
    </div><!-- /.content-wrapper -->

    <?php echo $__env->make('partials.controlsidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div><!-- ./wrapper -->

<?php echo $__env->make('partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<script>
    $(function () {
        var alert_type = '<?php echo $alert_type; ?>';
        var msg = '<?php echo $msg; ?>';
        if((alert_type != '') && (msg != '')){
            Command: toastr[alert_type](msg);
            alert_type = '';
            msg = '';
        }
    });
</script>
</body>
</html>