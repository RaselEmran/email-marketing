<?php $__env->startSection('main-content'); ?>

    <div class="nav-tabs-custom">
        <!-- Tabs within a box -->
        <ul class="nav nav-tabs">
            <li <?php if($errors->has() || isset($media)): ?> class="" <?php else: ?> class="active" <?php endif; ?> ><a href="#allMedia"
                                                                                                   data-toggle="tab">
                    <?php echo e(trans('common.all') . ' '. trans('common.media')); ?></a></li>
            <?php if(Auth::user()->role == 'admin' || (isset($media) && ($media->id == Auth::id()))): ?>
                <li <?php if($errors->has() || isset($media)): ?> class="active" <?php else: ?> class="" <?php endif; ?> ><a
                            href="#media"
                            data-toggle="tab"><?php echo e($title); ?></a>
                </li>
            <?php endif; ?>
        </ul>
        <div class="tab-content no-padding">
            <!-- ************** general *************-->
            <div <?php if($errors->has() || isset($media)): ?> class="tab-pane" <?php else: ?> class="tab-pane active"
                 <?php endif; ?> id="allMedia">

                <table class="table table-hover" id="dataTables">
                    <thead>
                    <tr class="active">
                        <th class="col-sm-1">#</th>
                        <th><?php echo trans('common.title'); ?></th>
                        <th><?php echo trans('common.media'); ?></th>
                        <th><?php echo trans('common.action'); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php if(count($medias ) > 0): ?>
                        <?php foreach($medias  as $key =>$list): ?>
                            <tr>
                                <td><?php echo $key+1; ?></td>
                                <td><?php echo e($list->title); ?></td>
                                <td><img src="<?php echo e(asset('upload/'. $list->path)); ?>" style="height: 100px; width: 120px" class="img-responsive"></td>

                                <td>
                                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['media.destroy', $list->id], 'class' => 'delete-form']); ?>

                                    <?php echo btn_edit("media/$list->id/edit"); ?>

                                    <?php echo btn_delete_submit(); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div <?php if($errors->has() || isset($media)): ?> class="tab-pane active" <?php else: ?> class="tab-pane"
                 <?php endif; ?> id="media">

                <?php if( !isset($media) ): ?>
                    <?php echo Form::open(['url' => "media",'id'=>'media', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'No', 'files' => true]); ?>


                    <?php echo $__env->make('media._form',['submit_button' => 'Submit'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <?php echo Form::model($media,['method' =>'PUT', 'url' => ["media",$media->id],'id'=>'media', 'role' => 'form', 'data-toggle' => 'form-ajax', 'data-url' => 'Yes', 'files' => true]); ?>


                    <?php echo $__env->make('media._form',['submit_button' => 'Update'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <?php echo Form::close(); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>